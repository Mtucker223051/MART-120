function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  
  //head & body
  ellipse(200,200,200,250)
  rect(100,340,200,59)
  triangle(100,399,100,340,50,399)
  triangle(300,399,300,340,350,399)
  rect(190,325,24,15)

  //center of glasses
  strokeWeight(2)
  point(200,175)
  strokeWeight(1)
  
  //hair, glasses, nose lines
  line(108,245,225,120)
  line(225,78,225,120)
  line(225,122,287,260)
  line(175,175,250,175)
  line(200,175,190,210)
  line(200,175,210,210)
  line(190,210,143,210)
  line(210,210,264,210)
  line(195,210,190,240)
  line(190,240,215,240)
  
  //nose point
  strokeWeight(2)
  point(190,240)
  strokeWeight(1)
  
  //eyes
  ellipse(176,193,37,14)
  ellipse(225,193,37,14)
  strokeWeight(13)
  point(175,193)
  strokeWeight(1)
  strokeWeight(13)
  point(225,193)
  strokeWeight(1)

  //mouth corners
  strokeWeight(2)
  point(160,270)
  strokeWeight(1)
  
  strokeWeight(2)
  point(240,270)
  strokeWeight(1)
  
  //hair down to shoulders
  triangle(102,338,108,244,150,338)
  triangle(300,338,289,259,252,338) 
  
  //upper lip on mouth
  triangle(160,270,190,260,200,270)
  triangle(200,270,210,260,240,270) 
  
  //lower lip on mouth
  line(160,270,180,280)
  line(180,280,220,280)
  line(220,280,240,270)
  
  textSize(40)
  text('Marissa Tucker',55,50)
  
}