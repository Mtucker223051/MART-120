var redColor = 123;
var greenColor = 45;
var blueColor = 75;

var x = 10;
var y = 100;
var diameter = 25;
var movement = 3;

var headX = 200;
var headY = 200;
var headDirection = 1;

var bodyX = 100;
var bodyY = 340;
var bodyDirection = -2;

var LeyeX = 176;
var LeyeY = 193;
var LeyeDirection = 1;

var ReyeX = 225
var ReyeY = 193
var ReyeDirection = -1;

var size = 20;
var count = 0;
var sizeDirection = 2;

// This is the set up function
function setup() {
  createCanvas(400, 400);
  movement = floor(random() * 3) + 1;
 }

function draw() {
  background(redColor,greenColor,blueColor);
  fill(255);  
  circle(x,y,diameter);
  fill(redColor,greenColor,blueColor);
  circle(x,y,15);
  x+=5
  y+=5
  if(y > height) {
    y = 0;}
  
  //head & body
  fill(255,204,75);
  ellipse(headX,headY,200,250);
  headX +=headDirection;
  if (headX >=320 || headX <= 100)
    {headDirection *= -1;}
  rect(190,325,24,15)
  fill(100,100,100);
  rect(100,bodyY,200,59);
  bodyY +=bodyDirection;
  if (bodyY <=0 || bodyY >=340)
     {bodyDirection *= -1;}
  fill(50,50,50);
  triangle(100,399,100,340,50,399)
  triangle(300,399,300,340,350,399)
  
  //center of glasses
  strokeWeight(2)
  point(200,175)
  strokeWeight(1)
  
  //hair, glasses, nose lines
  line(108,245,225,120)
  line(225,78,225,120)
  line(225,122,287,260)
  line(175,175,250,175)
  line(200,175,190,210)
  line(200,175,210,210)
  line(190,210,143,210)
  line(210,210,264,210)
  line(195,210,190,240)
  line(190,240,215,240)
  
  //nose point
  strokeWeight(2)
  point(190,240)
  strokeWeight(1)
  
  //eyes
  fill(255);
  ellipse(LeyeX,LeyeY,37,14)
  LeyeX +=LeyeDirection;
  if (LeyeX >=320 || LeyeX <=100)
     {LeyeDirection *= -1;}
  
  ellipse(ReyeX,ReyeY,37,14)
  ReyeY +=ReyeDirection;
  if (ReyeY >=320 || ReyeY <=100)
     {ReyeDirection *= -1;}
  
  strokeWeight(13)
  point(175,193)
  strokeWeight(1)
  strokeWeight(13)
  point(225,193)
  strokeWeight(1)

  //mouth corners
  strokeWeight(2)
  point(160,270)
  strokeWeight(1)
  
  strokeWeight(2)
  point(240,270)
  strokeWeight(1)
  
  //hair down to shoulders
  fill(255,204,75);
  triangle(102,338,108,244,150,338)
  triangle(300,338,289,259,252,338) 
  
  //upper lip on mouth
  fill(200,50,25);
  triangle(160,270,190,260,200,270)
  triangle(200,270,210,260,240,270) 
  
  //lower lip on mouth
  line(160,270,180,280)
  line(180,280,220,280)
  line(220,280,240,270)
  
  fill(250);
  textSize(size);
  size+= sizeDirection;
  count++;
  if(count > 5)
    {sizeDirection *=-1;
    count = 0;}
  text("Marissa Tucker",100,55);
  
}